from django.db import models
from django.contrib.auth.models import User
# Create your models here.

TITLE_CHOICES=[
    ('Farmer','Farmer'),
    ('Chariot','Chariot'),
    ('Developer','Developer'),
    ('Doctor','Doctor'),
    ('Politician','Politician'),
    ('House-wife','House-wife')
    ]


class Profile(models.Model):
    user=models.OneToOneField(User,null=True,on_delete=models.CASCADE)
    title=models.CharField(max_length=15,choices=TITLE_CHOICES,default='farmer')
    profile_pic=models.ImageField(upload_to='product',null=True,blank=True)
    contact_num=models.CharField(max_length=15,null=True)
    gender=models.CharField(max_length=6,choices=[('male','male'),('female','female')],default='male')
    dob=models.DateField(null=True)
    bio=models.TextField(null=True,blank=True)
    address=models.TextField(null=True,blank=True)
    def __str__(self):
        return self.user.username


CATEGORY_CHOICES=(
    ('vegitables','vegitables'),
    ('fruits','fruits'),
    ('dairy','dairy'),
    ('chocolates','chocolates'),
    ('cosmetics','cosmetics'),
    ('liquor','liquor'),
)

class Product(models.Model):
    title=models.CharField(max_length=30,null=True,blank=True)
    price=models.IntegerField(null=True,blank=True)
    category=models.CharField(choices=CATEGORY_CHOICES, max_length=15,null=True,blank=True)
    info=models.TextField(default='',null=True,blank=True)
    product_image=models.ImageField(upload_to='product',default='/product/images.png',null=True,blank=True)
    quantity=models.CharField(max_length=20,default='',null=True,blank=True)
    item_stock=models.IntegerField(default='',null=True,blank=True)
    discount=models.IntegerField(default='',null=True,blank=True)
    rating=models.FloatField(default=0,null=True,blank=True)
    rating_count=models.IntegerField(default=0,null=True,blank=True)
    def __str__(self):
        return self.title or 'no title'
    

STATE_CHOICE=(
    ('andhra pradesh','andhra pradesh'),
    ('telangana','telangana'),
    ('karnataka','karnataka'),
    ('tamilnadu','tamilnadu'),
    ('kerala','kerala'),
    ('goa','goa'),
    ('Maharashtra','Maharashtra'),
    ('madya pradesh','madya pradesh'),
    ('utter pradesh','utter pradesh'),
    ('rajasthan','rajasthan'),
    ('gujarat','gujarat'),
    ('haryana','haryana'),
    ('panjab','panjab'),
    ('delhi','delhi'),
    ('bihar','bihar'),
    ('west bengal','west bengal'),
    ('odisa','odisa'),
    ('Jharkhand','Jharkhand'),
    ('Chhattisgarh','Chhattisgarh'),
    ('himachal pradesh','himachal pradesh'),
    ('arunachal pradesh','arunachal pradesh'),
    ('jammu kasmir','jammu kasmir'),
    ('uttarakand','uttarakand'),
    ('nagaland','nagaland'),
    ('megalaya','megalaya'),
    ('tripura','tripura'),
    ('sikkim','sikkim'),
    ('mizoram','mizoram'),
    ('assam','assam'),
    ('Manipur','Manipur'),
    ('Andaman and Nicobar','Andaman and Nicobar'),
    ('Chandigarh','Chandigarh'),
    ('Dadra and Nagar Haveli','Dadra and Nagar Haveli'),
    ('Lakshadweep','Lakshadweep'),
    ('Puducherry','Puducherry'),
    ('Ladakh','Ladakh'),
    ('Daman and Diu','Daman and Diu'),
)
class Customer(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=30)
    locality=models.CharField(max_length=30)
    city=models.CharField(max_length=30)
    mobile=models.IntegerField(null=True)
    pincode=models.IntegerField()
    state=models.CharField(choices=STATE_CHOICE,max_length=30)
    status=models.BooleanField(default=False)
    def __str__(self):
        return self.name
    
class Cart(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)
    rating=models.IntegerField(default=0)
    
    def price(self):
        return self.product.price
    @property
    def total_product_price(self):
        return self.quantity*self.product.price
    
STATUS_CHOICE=(
    ('accepted','accepted'),
    ('pending','pending'),
    ('cancel','cancel'),
    ('delivered','delivered'),
    ('packed','packed'),
    ('on-the-way','on-the-way'),
)

class Payment(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    amount=models.FloatField()
    razorpay_order_id=models.CharField(max_length=100,blank=True,null=True)
    razorpay_payment_id=models.CharField(max_length=100,null=True,blank=True)
    razorpay_payment_status=models.CharField(max_length=100,blank=True,null=True)
    cust_add_id=models.CharField(max_length=100,blank=True,null=True)
    paid=models.BooleanField(default=False)

class orderPlaced(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)
    ordered_date=models.DateTimeField(auto_now_add=True)
    status=models.CharField(max_length=50,choices=STATUS_CHOICE,default='pending')
    payment=models.ForeignKey(Payment,on_delete=models.CASCADE,default="")
    review=models.TextField(default='',null=True,blank=True)
    rating=models.IntegerField(default=0,null=True,blank=True)
    @property
    def total_cost(self):
        return self.quantity*self.product.price

class Wishlist(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)


class DiscountCards(models.Model):
    bank=models.CharField(max_length=20,blank=True,null=True)
    card_image=models.ImageField(upload_to='product')
    discount_rate=models.IntegerField()


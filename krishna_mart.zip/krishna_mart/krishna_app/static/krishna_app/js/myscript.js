$(document).ready(function(){
    $('.minus-cart').click(function(){
        var id=$(this).attr('pid').toString()
        var iT=this.parentNode.parentNode.parentNode.parentNode.children[1].children[1].children[1].children[1]
        var total_product_price = this.parentNode.parentNode.parentNode.parentNode.children[2].children[1]

        $.ajax({
            type: 'GET',
            url: '/minus-cart',
            data: {
                'product_id': id
            },
            success: function (data) {
                if (data.quantity > 0) {
                    iT.innerText = data.quantity;
                    total_product_price.innerText =data.total_product_price
                    document.getElementById('amount').innerText = 'Rs. ' + data.amount;
                    document.getElementById('total_amount').innerText = 'Rs. ' + data.total_amount;
                    document.getElementById('totalItems').innerText = data.totalItems;
                }
                else {
                    document.getElementById('amount').innerText = 'Rs. ' + data.amount;
                    document.getElementById('total_amount').innerText = 'Rs. ' + data.total_amount;
                    iT.parentNode.parentNode.remove();
                    document.getElementById('totalItems').innerText = data.totalItems;
                    if (data.cart_length == 0) {
                        $('.cart-load').load(' .cart-load');
                    }

                }
            }
        })


        
        
    })
})

$(document).ready(function(){
    $('.plus-cart').click(function(){
        var id=$(this).attr('pid').toString()
        var iT=this.parentNode.parentNode.parentNode.parentNode.children[1].children[1].children[1].children[1]
        var total_product_price = this.parentNode.parentNode.parentNode.parentNode.children[2].children[1]
        $.ajax({
            type: 'GET',
            url: '/plus-cart',
            data: {
                'prod_id': id
            },
            success: function (data) {
                iT.innerText = data.quantity
                total_product_price.innerText =data.total_product_price;
                document.getElementById('amount').innerText = 'Rs. ' + data.amount;
                document.getElementById('total_amount').innerText = 'Rs. ' + data.total_amount;
            },
            error: function (data) {
                alert('you can\'t add more quantities.\n item is out of stock');
            }
        })
    })
})


$(document).ready(function () {
    $('.remove-cart').click(function () {
        var iT = this
        var id = $(this).attr('pid').toString()
        $.ajax({
            type: "GET",
            url: '/remove-cart',
            data: {
                'prod_id': id
            },
            success: function (data) {
                document.getElementById('amount').innerText = data.amount;
                document.getElementById('total_amount').innerText = data.total_amount;
                iT.parentNode.parentNode.parentNode.remove();
                document.getElementById('totalItems').innerText = data.totalItems;

                if (data.cart_length == 0) {
                    $('.cart-load').load(' .cart-load');
                }
            }
        })
    })
})

$(document).ready(function () {
    $('.wishlist').click(function () {
        var id = $(this).attr('pid').toString()
        $.ajax({
            type: 'GET',
            url: '/wishlist-count',
            data: {
                'prod_id': id
            },
            success: function (data) {
                $('#wishlist-heart').load(' #wishlist-heart');
                document.getElementById('totalWishlistItems').innerText = data.totalWishlistItems;
            }
        })
    })
})
 
$(document).ready(function () {
    $('.remove-wishlist').click(function () {
        var id = $(this).attr('pid').toString()
        var iT = this
        $.ajax({
            type: "GET",
            url: '/remove-wishlist',
            data: {
                'prod_id': id
            },
            success: function (data) {
                iT.parentNode.parentNode.remove();
                document.getElementById('totalWishlistItems').innerText = data.totalWishlistItems;
                if(data.totalWishlistItems==0){
                    $('.load-wishlist').load(' .load-wishlist');
                }
            }
        })
    })
})

$(document).ready(function () {
    $('.form-check-input').click(function () {
        

        var id = $(this).attr('id').toString();
        $.ajax({
            type: "POST",
            url: '/shipping-address',
            data: {
                'cust_id': id,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val(),
            },
            success: function (data) {
                $('#address-list').load(' #address-list');
            }
        })
    })
})




